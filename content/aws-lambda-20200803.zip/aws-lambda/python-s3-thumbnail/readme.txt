Please install the following plugin:
https://github.com/UnitedIncome/serverless-python-requirements

```
npm install --save serverless-python-requirements
```
